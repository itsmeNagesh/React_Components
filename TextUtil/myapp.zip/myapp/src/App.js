
import './App.css';
import Textform from './Components/Textform';
import About  from './Components/About'
import Layout  from './Components/Layout'
import Service from './Components/Service'
import Nopage from './Components/Nopage'
import Footer from './Components/Footer'

import { BrowserRouter, Routes, Route } from "react-router-dom";


function App() {
  return (
 <>
 <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Textform tittle="Text utils"/>} />
          <Route path="About" element={<About />} />
          <Route path="Service" element={<Service />} />
          <Route path="Nopage" element={<Nopage />} />
        </Route>
      </Routes>
    </BrowserRouter>
    <Footer/>
 </>
  );
}

export default App;
